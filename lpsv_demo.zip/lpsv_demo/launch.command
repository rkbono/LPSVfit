#!/bin/bash
# LPSVfit demo launcher (macOS)
# Double-click this file to start the local server and open the app.

cd "$(dirname "$0")"

PORT=8765
# Find a free port if 8765 is taken
while lsof -i :$PORT >/dev/null 2>&1; do
  PORT=$((PORT + 1))
done

echo "Starting LPSVfit demo on http://localhost:$PORT"
echo "Press Ctrl+C to stop."
echo ""

# Open browser after a short delay
(sleep 1 && open "http://localhost:$PORT/index.html") &

# Serve this directory
python3 -m http.server $PORT --bind 127.0.0.1
