@echo off
REM LPSVfit demo launcher (Windows)
REM Double-click this file to start the local server and open the app.
REM Requires Python 3 on PATH.

cd /d "%~dp0"

set PORT=8765

echo Starting LPSVfit demo on http://localhost:%PORT%
echo Press Ctrl+C to stop.
echo.

REM Open browser in background, then start server (which blocks)
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:%PORT%/index.html"
python -m http.server %PORT% --bind 127.0.0.1

pause
